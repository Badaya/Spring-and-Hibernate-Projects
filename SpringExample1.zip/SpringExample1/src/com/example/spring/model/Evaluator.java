package com.example.spring.model;

public class Evaluator {

	public void evaluate(int value) {
		System.out.println("Evaluated value is : " + (value * 5 ));
	}
}
