package com.sample.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sample.onramp.model.UserEntity;
import com.sample.service.UserService;

public class MainApp {

	public static void main(String[] args) {
		try{
			ApplicationContext context = new ClassPathXmlApplicationContext(
					"onramp-dao-infrastructure.xml", 
					"onramp-daos.xml");
			
			UserEntity user = new UserEntity();
			user.setAdmin(true);
			user.setFirstName("Bhavin");
			user.setLastName("Rajani");
			user.setFullName("Bhavin Rajani");
			
			user.setManager(true);
			user.setRegion("LA");
			user.setRole("LA-Manager");
			user.setSalesForceId("SAL000123442");
			
			UserService service = context.getBean(UserService.class);
			service.saveUserEntity(user);
			
		}catch(Exception exc) {
			exc.printStackTrace();
		}
	}
}
